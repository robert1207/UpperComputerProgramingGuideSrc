源码中包含以下内容：
- BreadpadDemo源码（在MacOS和Windows7下测试验证通过）
- 用于MaxOS的“dump_syms”和“minidump_stackwalk”工具集合(包含脚本)
- 用于Windows的“dump_syms”和“minidump_stackwalk”工具集合(包含脚本)
- 用于在wiindows下编译“dump_syms”的msdia_dll